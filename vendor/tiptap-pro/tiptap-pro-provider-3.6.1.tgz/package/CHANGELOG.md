# Change Log

## 3.6.1

## 3.6.0

## 3.5.0

### Minor Changes

- a75214c: Support for versions v2, which allows adding meta data to versions.

## 3.4.1

## 3.4.0

## 3.3.1

### Patch Changes

- f514527: TiptapCollabProvier: include provider version in URL when connecting to the collab server
- f627148: TiptapCollabProvider: wrap enable/disable auto versioning to avoid execution before document has synced
- 80674ca: performance optinizations for Y operations
- 84cb868: TiptapCollabProvider: add handling for stateless document.saved message

## 3.3.0

## 3.2.1

## 3.2.0

## 3.1.0

### Patch Changes

- 08dcfb4: Update package.json homepage field to the correct URL value

## 3.0.1

### Patch Changes

- a37128f: move @tiptap-cloud/provider to @tiptap-pro/provider

## 3.0.0

### Major Changes

- 953106f: Updated all tiptap dependencies

### Patch Changes

- 40d6b02: updated tiptap and hocuspocus dependencies
- 8292f35: Initialized Changesets
- 77a7769: Bumped @tiptap and @hocuspocus dependencies
- 7f9455b: Bumped Tiptap and Hocuspocus Dependencies to most recent version
- ab1991c: Bumped hocuspocus provider dependencies
- 6b08d0c: Bumped tiptap and hocuspocus dependencies
- b31ecec: Updated tiptap packages
- 1f02197: Make all packages be published with the same version
- 90d4005: Fixed an issue where the provider would not attach itself automatically
- e369685: upgraded hocuspocus and tiptap dependencies
- aca403d: Bump tiptap and hocuspocus dependencies

## 3.0.0-beta.31

## 3.0.0-beta.30

### Patch Changes

- 7f9455b: Bumped Tiptap and Hocuspocus Dependencies to most recent version

## 3.0.0-beta.29

## 3.0.0-beta.28

## 3.0.0-beta.27

## 3.0.0-beta.26

## 3.0.0-beta.25

### Patch Changes

- 77a7769: Bumped @tiptap and @hocuspocus dependencies

## 3.0.0-beta.24

### Patch Changes

- aca403d: Bump tiptap and hocuspocus dependencies

## 3.0.0-beta.23

## 3.0.0-beta.22

### Patch Changes

- e369685: upgraded hocuspocus and tiptap dependencies

## 3.0.0-beta.21

### Patch Changes

- 1f02197: Make all packages be published with the same version

## 3.0.0-beta.5

### Patch Changes

- 6b08d0c: Bumped tiptap and hocuspocus dependencies

## 3.0.0-beta.4

### Patch Changes

- 40d6b02: updated tiptap and hocuspocus dependencies

## 3.0.0-beta.3

### Patch Changes

- ab1991c: Bumped hocuspocus provider dependencies

## 3.0.0-beta.2

### Patch Changes

- b31ecec: Updated tiptap packages
- 90d4005: Fixed an issue where the provider would not attach itself automatically

## 3.0.0-beta.1

### Major Changes

- 953106f: Updated all tiptap dependencies

## 2.17.6-next.0

### Patch Changes

- 8292f35: Initialized Changesets

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.21.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.4...v2.21.5) (2025-06-18)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.21.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.3...v2.21.4) (2025-06-12)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.21.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.2...v2.21.3) (2025-06-11)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.21.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.1...v2.21.2) (2025-06-11)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.21.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.0...v2.21.1) (2025-06-10)

**Note:** Version bump only for package @tiptap-cloud/provider

# [2.21.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.20.2...v2.21.0) (2025-05-30)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.20.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.20.1...v2.20.2) (2025-05-29)

### Features

- tiptapcollabprovider: allow specifying which fields to revert ([#264](https://github.com/ueberdosis/tiptap-pro/issues/264)) ([48e4768](https://github.com/ueberdosis/tiptap-pro/commit/48e4768bc1089235251fe7ffdd193c2b4f0e71fe))

## [2.20.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.20.0...v2.20.1) (2025-05-29)

**Note:** Version bump only for package @tiptap-cloud/provider

# [2.20.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.19.2...v2.20.0) (2025-05-28)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.19.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.19.1...v2.19.2) (2025-05-25)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.19.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.19.0...v2.19.1) (2025-05-15)

**Note:** Version bump only for package @tiptap-cloud/provider

# [2.19.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.18.2...v2.19.0) (2025-05-14)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.18.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.18.1...v2.18.2) (2025-05-13)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.18.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.18.0...v2.18.1) (2025-05-12)

**Note:** Version bump only for package @tiptap-cloud/provider

# [2.18.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.8...v2.18.0) (2025-04-17)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.17.8](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.7...v2.17.8) (2025-04-11)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.17.7](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.6...v2.17.7) (2025-04-11)

### Features

- change provider package to use hocuspocus v3 ([ad1ce1c](https://github.com/ueberdosis/tiptap-pro/commit/ad1ce1c5ea0a2780f478f973ca8c7f718d4c05c9))

## [2.17.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.5...v2.17.6) (2025-03-29)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.17.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.5-beta.0...v2.17.5) (2025-02-26)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.17.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.3...v2.17.4) (2025-02-11)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.17.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.2...v2.17.3) (2025-01-30)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.17.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.1...v2.17.2) (2025-01-07)

**Note:** Version bump only for package @tiptap-cloud/provider

## [2.17.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.0...v2.17.1) (2024-12-30)

**Note:** Version bump only for package @tiptap-cloud/provider

# [2.17.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.16.5-beta.2...v2.17.0) (2024-12-20)

### Features

- adds TiptapCollabProvider ([#153](https://github.com/ueberdosis/tiptap-pro/issues/153)) ([79db810](https://github.com/ueberdosis/tiptap-pro/commit/79db810db1734bde0a5dc30455acff70230a33c5))

## [2.9.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.9.2...v2.9.3) (2024-07-05)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.9.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.9.1...v2.9.2) (2024-06-28)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.9.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.9.0...v2.9.1) (2024-06-26)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.9.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.9...v2.9.0) (2024-06-26)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.8.9](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.8...v2.8.9) (2024-06-03)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.8.8](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.7...v2.8.8) (2024-05-27)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.8.7](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.6...v2.8.7) (2024-05-15)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.8.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.5...v2.8.6) (2024-05-08)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.8.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.4...v2.8.5) (2024-05-08)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.8.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.3...v2.8.4) (2024-05-08)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.8.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.2...v2.8.3) (2024-05-08)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.8.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.1...v2.8.2) (2024-05-06)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.8.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.0...v2.8.1) (2024-04-12)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.8.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.7...v2.8.0) (2024-04-05)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.7.7](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.6...v2.7.7) (2024-03-28)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.7.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.5...v2.7.6) (2024-03-14)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.7.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.4...v2.7.5) (2024-02-20)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.7.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.3...v2.7.4) (2024-02-20)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.7.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.1...v2.7.3) (2024-02-20)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.7.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.1...v2.7.2) (2024-02-16)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.7.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.0...v2.7.1) (2024-02-16)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.7.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.5...v2.7.0) (2024-02-15)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.6.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.4...v2.6.5) (2024-02-07)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.6.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.3...v2.6.4) (2024-01-29)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.6.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.2...v2.6.3) (2024-01-22)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.6.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.1...v2.6.2) (2024-01-19)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.6.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.3...v2.6.1) (2024-01-16)

### Reverts

- Revert "switch to rc tiptap versions for release candidate" ([d397698](https://github.com/ueberdosis/tiptap-pro/commit/d39769817f2cc39e919b73e0bb18072bcc46dd45))

# [2.6.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.0-rc.0...v2.6.0) (2024-01-09)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.5.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.5.1...v2.5.2) (2024-01-09)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.5.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.5.0...v2.5.1) (2023-12-08)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.5.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.4.1...v2.5.0) (2023-11-27)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.4.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.4.0...v2.4.1) (2023-11-21)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.4.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.4...v2.4.0) (2023-11-16)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.3.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.3...v2.3.4) (2023-11-15)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.3.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.2...v2.3.3) (2023-10-14)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.3.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.1...v2.3.2) (2023-10-12)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.3.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.0...v2.3.1) (2023-10-06)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.3.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.4...v2.3.0) (2023-09-27)

## [2.2.2-rc.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.2...v2.2.2-rc.3) (2023-09-04)

## [2.2.2-rc.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.1...v2.2.2-rc.2) (2023-09-04)

## [2.2.2-rc.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.0...v2.2.2-rc.1) (2023-09-04)

## [2.2.2-rc.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.1...v2.2.2-rc.0) (2023-08-22)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.2.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.3...v2.2.4) (2023-09-19)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.2.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2...v2.2.3) (2023-09-11)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.2.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.1...v2.2.2) (2023-09-08)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.2.2-rc.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.2...v2.2.2-rc.3) (2023-09-04)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.2.2-rc.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.1...v2.2.2-rc.2) (2023-09-04)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.2.2-rc.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.0...v2.2.2-rc.1) (2023-09-04)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.2.2-rc.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.1...v2.2.2-rc.0) (2023-08-22)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.2.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0...v2.2.1) (2023-08-22)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.2.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.6...v2.2.0) (2023-08-19)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.2.0-rc.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.5...v2.2.0-rc.6) (2023-08-11)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.2.0-rc.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.4...v2.2.0-rc.5) (2023-08-09)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.2.0-rc.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.3...v2.2.0-rc.4) (2023-08-04)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.2.0-rc.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.2...v2.2.0-rc.3) (2023-07-31)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.2.0-rc.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.1...v2.2.0-rc.2) (2023-07-26)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.2.0-rc.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.0...v2.2.0-rc.1) (2023-07-26)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.2.0-rc.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.1.0...v2.2.0-rc.0) (2023-07-22)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.1.0](https://github.com/ueberdosis/tiptap-workspace/compare/v2.1.0-rc.7...v2.1.0) (2023-07-10)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.1.0-rc.7](https://github.com/ueberdosis/tiptap-pro/compare/v2.1.0-rc.6...v2.1.0-rc.7) (2023-06-25)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.1.0-rc.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.1.0-rc.5...v2.1.0-rc.6) (2023-06-24)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.1.0-rc.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.1.0-rc.4...v2.1.0-rc.5) (2023-06-12)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.1.0-rc.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.1.0-rc.3...v2.1.0-rc.4) (2023-06-12)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

## [2.0.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.1...v2.0.2) (2023-04-27)

### Bug Fixes

- **extension-emoji:** prevent emoji in code block splitting it up ([b913592](https://github.com/ueberdosis/tiptap-pro/commit/b9135927a76400c42f6e6188fc5cf78436271fac))

## [2.0.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0...v2.0.1) (2023-04-14)

### Bug Fixes

- **emojis:** fix fallback images not being used when emoji not supported ([8d41674](https://github.com/ueberdosis/tiptap-pro/commit/8d41674bc8051264c66fb9ac43b406a806b3cf89))

# [2.0.0-beta.240](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.239...v2.0.0-beta.240) (2023-03-15)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.239](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.238...v2.0.0-beta.239) (2023-03-15)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.238](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.237...v2.0.0-beta.238) (2023-03-15)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.237](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.236...v2.0.0-beta.237) (2023-03-01)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.236](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.235...v2.0.0-beta.236) (2023-02-28)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.235](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.234...v2.0.0-beta.235) (2023-02-28)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.234](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.233...v2.0.0-beta.234) (2023-02-28)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.233](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.232...v2.0.0-beta.233) (2023-02-28)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.232](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.231...v2.0.0-beta.232) (2023-02-28)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.231](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.230...v2.0.0-beta.231) (2023-02-23)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.230](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.229...v2.0.0-beta.230) (2023-02-23)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.229](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.228...v2.0.0-beta.229) (2023-02-21)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.228](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.227...v2.0.0-beta.228) (2023-02-21)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.227](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.226...v2.0.0-beta.227) (2023-02-21)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.226](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.225...v2.0.0-beta.226) (2023-02-20)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.225](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.224...v2.0.0-beta.225) (2023-02-17)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.224](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.223...v2.0.0-beta.224) (2023-02-17)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.223](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.222...v2.0.0-beta.223) (2023-02-15)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.222](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.221...v2.0.0-beta.222) (2023-02-15)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.221](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.220...v2.0.0-beta.221) (2023-02-14)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.220](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.219...v2.0.0-beta.220) (2023-02-13)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.219](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.218...v2.0.0-beta.219) (2023-02-13)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.218](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.217...v2.0.0-beta.218) (2023-02-13)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.217](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.209...v2.0.0-beta.217) (2023-02-09)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.209](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.208...v2.0.0-beta.209) (2022-12-16)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.208](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.203...v2.0.0-beta.208) (2022-12-16)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.203](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.202...v2.0.0-beta.203) (2022-11-24)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.202](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.201...v2.0.0-beta.202) (2022-11-04)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.201](https://github.com/ueberdosis/tiptap-pro/compare/v2.0.0-beta.200...v2.0.0-beta.201) (2022-11-04)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# 2.0.0-beta.200 (2022-11-04)

### Bug Fixes

- fix a typo in EmojiItem ([8773249](https://github.com/ueberdosis/tiptap-pro/commit/87732496e7cc15ebd2ad43b5b44b6deb072d1d68))
- fixes an error when using the emoji extension and pasting text ending with ":" ([9620d19](https://github.com/ueberdosis/tiptap-pro/commit/9620d195448bb4969f3657336c766dbd59f47ea2))
- **maintainment:** fix typescript errors in packages ([c910afe](https://github.com/ueberdosis/tiptap-pro/commit/c910afe658ff523256e6b7a411441afd98859cb6))
- **maintainment:** make use of npm instead of yarn ([bffbd67](https://github.com/ueberdosis/tiptap-pro/commit/bffbd67d9288be7da1b26c4d1ef98ad6cd6cdcd7))
- render fallback image if there is no emoji character ([9235218](https://github.com/ueberdosis/tiptap-pro/commit/92352186e894d87d08c26c840e5369bcdcbd26e9))
- use addOptions ([095639f](https://github.com/ueberdosis/tiptap-pro/commit/095639fb4ce09414b0005e68de04843c5a4c6100))

### Features

- add `forceFallbackImages` to emoji extension ([1a43713](https://github.com/ueberdosis/tiptap-pro/commit/1a43713cd67b4b7bf54b23f587ca9f4eb64df98c))
- add support for emoticons ([#6](https://github.com/ueberdosis/tiptap-pro/issues/6)) ([df0e472](https://github.com/ueberdosis/tiptap-pro/commit/df0e4720686606718a63fc74fe4af5f54b0e7695))

### Reverts

- Revert "Publish" ([2efaf21](https://github.com/ueberdosis/tiptap-pro/commit/2efaf21a0ec76527a3b50fe650c962fa69dab8c7))
- Revert "Publish" ([622263d](https://github.com/ueberdosis/tiptap-pro/commit/622263d45b31cc84fef4a20bee81f7510f9f1234))

# [2.0.0-beta.17](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.16...@tiptap-pro/extension-emoji@2.0.0-beta.17) (2022-02-07)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.16](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.15...@tiptap-pro/extension-emoji@2.0.0-beta.16) (2022-02-07)

### Bug Fixes

- fix a typo in EmojiItem ([8773249](https://github.com/ueberdosis/tiptap-pro/commit/87732496e7cc15ebd2ad43b5b44b6deb072d1d68))

# [2.0.0-beta.15](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.14...@tiptap-pro/extension-emoji@2.0.0-beta.15) (2022-01-26)

### Features

- add `forceFallbackImages` to emoji extension ([1a43713](https://github.com/ueberdosis/tiptap-pro/commit/1a43713cd67b4b7bf54b23f587ca9f4eb64df98c))

# [2.0.0-beta.14](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.13...@tiptap-pro/extension-emoji@2.0.0-beta.14) (2022-01-25)

### Bug Fixes

- render fallback image if there is no emoji character ([9235218](https://github.com/ueberdosis/tiptap-pro/commit/92352186e894d87d08c26c840e5369bcdcbd26e9))

# [2.0.0-beta.13](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.11...@tiptap-pro/extension-emoji@2.0.0-beta.13) (2022-01-25)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.11](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.10...@tiptap-pro/extension-emoji@2.0.0-beta.11) (2022-01-25)

### Bug Fixes

- fixes an error when using the emoji extension and pasting text ending with ":" ([9620d19](https://github.com/ueberdosis/tiptap-pro/commit/9620d195448bb4969f3657336c766dbd59f47ea2))

# [2.0.0-beta.10](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.9...@tiptap-pro/extension-emoji@2.0.0-beta.10) (2022-01-13)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.9](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.8...@tiptap-pro/extension-emoji@2.0.0-beta.9) (2022-01-10)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.8](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.7...@tiptap-pro/extension-emoji@2.0.0-beta.8) (2021-12-09)

### Features

- add support for emoticons ([#6](https://github.com/ueberdosis/tiptap-pro/issues/6)) ([df0e472](https://github.com/ueberdosis/tiptap-pro/commit/df0e4720686606718a63fc74fe4af5f54b0e7695))

# [2.0.0-beta.7](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.6...@tiptap-pro/extension-emoji@2.0.0-beta.7) (2021-12-03)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.6](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.5...@tiptap-pro/extension-emoji@2.0.0-beta.6) (2021-12-02)

**Note:** Version bump only for package @tiptap-pro/extension-emoji

# [2.0.0-beta.5](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.4...@tiptap-pro/extension-emoji@2.0.0-beta.5) (2021-11-17)

### Reverts

- Revert "Publish" ([2efaf21](https://github.com/ueberdosis/tiptap-pro/commit/2efaf21a0ec76527a3b50fe650c962fa69dab8c7))

# [2.0.0-beta.4](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.4...@tiptap-pro/extension-emoji@2.0.0-beta.4) (2021-11-17)

### Reverts

- Revert "Publish" ([2efaf21](https://github.com/ueberdosis/tiptap-pro/commit/2efaf21a0ec76527a3b50fe650c962fa69dab8c7))

# [2.0.0-beta.3](https://github.com/ueberdosis/tiptap-pro/compare/@tiptap-pro/extension-emoji@2.0.0-beta.3...@tiptap-pro/extension-emoji@2.0.0-beta.3) (2021-11-17)

### Reverts

- Revert "Publish" ([622263d](https://github.com/ueberdosis/tiptap-pro/commit/622263d45b31cc84fef4a20bee81f7510f9f1234))

# 2.0.0-beta.1 (2021-11-11)

**Note:** Version bump only for package @tiptap-pro/extension-emoji
