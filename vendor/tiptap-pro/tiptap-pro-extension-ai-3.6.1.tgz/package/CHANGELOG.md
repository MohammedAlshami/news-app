# Change Log

## 3.6.1

## 3.6.0

## 3.5.0

## 3.4.1

### Patch Changes

- 5567996: Reintroduce deleted `generatedWith.range` property of extension storage

## 3.4.0

### Patch Changes

- c0fad06: - Allow user edits during AI content streaming.
  - Fixes a bug where user edits during AI streaming would cause content to be inserted at incorrect positions.
  - Fixes a bug where the AI decoration would be shown in the incorrect positions while streaming
  - Fixes a bug where the incorrect content would be inserted in the document if the user rejected an edit.

## 3.3.1

## 3.3.0

## 3.2.1

### Patch Changes

- 11d880c: Publish a new version so that the latest tag is set to the v3 version of pro packages

## 3.2.0

### Minor Changes

- f6100e9: Support GPT-5 models

### Patch Changes

- cb66828: Fix streaming bugs where content was inserted in the wrong positions

  - Remove experimental "streaming v2" implementation. This approach has been abandoned because it had some drawbacks. Mainly, content was rendered as decorations so no decorations could be shown on top of it. Therefore, it did not integrate well with the Notion-like template.
  - Modify the aiStream command with a new implementation of streaming. In this new version, the new document (with the streamed content) is compared with the current document using the prosemirror-changeset library. Thanks to this system, the content is always inserted in the exact positions where it should go. This fixes the bug where streamed content is inserted in the wrong position.
  - Fix a bug where content is not inserted in a new paragraph when it should be. For example, if the AI inserted a h2 tag inside a paragraph, the h2 tag would be converted into a paragraph instead of being inserted into a new paragraph. Now, with the new streaming implementation, the extension intelligently decides when to insert content into a new paragraph and when to insert it in the same paragraph (see replace-range-with-fragment.ts file for the implementation).
  - Fix a bug that occurred while converting the streamed content to a fragment, where an empty text node was inserted after a block node.
  - Modify the demos so that they do not use the experimental "streaming v2" implementation.

## 3.1.0

### Minor Changes

- 699eef4: Add stream v2 implementation that solves bug where incorrect content gets deleted or added while streaming

### Patch Changes

- 08dcfb4: Update package.json homepage field to the correct URL value

## 3.0.1

## 3.0.0

### Major Changes

- 953106f: Updated all tiptap dependencies

### Minor Changes

- a819f5a: Use decorations to render AI-generated content
- 05d3091: Enable developers to customize the autocomplete trigger and define an autocomplete-as-you-type behaviour

### Patch Changes

- 40d6b02: updated tiptap and hocuspocus dependencies
- 95edb66: Send spaces to backend so that the response respects the spaces between words in autocomplete response
- 8292f35: Initialized Changesets
- 77a7769: Bumped @tiptap and @hocuspocus dependencies
- 7f9455b: Bumped Tiptap and Hocuspocus Dependencies to most recent version
- 828eb51: Let developers mark new commands as regenerations
- 4a35f7e: Rename isRegenerate param to regenerate to make the naming more consistent
- 6b08d0c: Bumped tiptap and hocuspocus dependencies
- b31ecec: Updated tiptap packages
- e369685: upgraded hocuspocus and tiptap dependencies
- aca403d: Bump tiptap and hocuspocus dependencies

## 3.0.0-beta.31

## 3.0.0-beta.30

### Patch Changes

- 7f9455b: Bumped Tiptap and Hocuspocus Dependencies to most recent version

## 3.0.0-beta.29

## 3.0.0-beta.28

## 3.0.0-beta.27

## 3.0.0-beta.26

## 3.0.0-beta.25

### Patch Changes

- 77a7769: Bumped @tiptap and @hocuspocus dependencies

## 3.0.0-beta.24

### Patch Changes

- aca403d: Bump tiptap and hocuspocus dependencies

## 3.0.0-beta.23

## 3.0.0-beta.22

### Patch Changes

- e369685: upgraded hocuspocus and tiptap dependencies

## 3.0.0-beta.21

### Patch Changes

- 828eb51: Let developers mark new commands as regenerations
- 4a35f7e: Rename isRegenerate param to regenerate to make the naming more consistent

## 3.0.0-beta.20

### Patch Changes

- 6b08d0c: Bumped tiptap and hocuspocus dependencies

## 3.0.0-beta.19

### Minor Changes

- a819f5a: Use decorations to render AI-generated content
- 05d3091: Enable developers to customize the autocomplete trigger and define an autocomplete-as-you-type behaviour

### Patch Changes

- 95edb66: Send spaces to backend so that the response respects the spaces between words in autocomplete response

## 3.0.0-beta.18

### Patch Changes

- 40d6b02: updated tiptap and hocuspocus dependencies

## 3.0.0-beta.17

## 3.0.0-beta.16

### Patch Changes

- b31ecec: Updated tiptap packages

## 3.0.0-beta.15

### Major Changes

- 953106f: Updated all tiptap dependencies

## 3.0.0-next.1

## 3.0.0-next.0

### Patch Changes

- 8292f35: Initialized Changesets

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.21.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.4...v2.21.5) (2025-06-18)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.21.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.3...v2.21.4) (2025-06-12)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.21.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.2...v2.21.3) (2025-06-11)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.21.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.1...v2.21.2) (2025-06-11)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.21.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.21.0...v2.21.1) (2025-06-10)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.21.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.20.2...v2.21.0) (2025-05-30)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.20.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.20.1...v2.20.2) (2025-05-29)

### Bug Fixes

- calculate last index of the document correctly ([1f2fa2b](https://github.com/ueberdosis/tiptap-pro/commit/1f2fa2b286751c5d2f10de8a490c675feb95bf48))

## [2.20.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.20.0...v2.20.1) (2025-05-29)

### Bug Fixes

- export unsetAllAiMarks command and simplify its code ([6793832](https://github.com/ueberdosis/tiptap-pro/commit/6793832c457727d7d714d656ab594dd585bf3884))

# [2.20.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.19.2...v2.20.0) (2025-05-28)

### Bug Fixes

- prevent trailing text from appearing after the content when you stream AI-generated content ([#283](https://github.com/ueberdosis/tiptap-pro/issues/283)) ([676b1ca](https://github.com/ueberdosis/tiptap-pro/commit/676b1caad44dbd7ec934736c5e07536643dd4a06))
- remove redundant serialization and deserialization step ([#279](https://github.com/ueberdosis/tiptap-pro/issues/279)) ([91b15cd](https://github.com/ueberdosis/tiptap-pro/commit/91b15cdec932e7ee3188ac8ff0c5b1f4302ba990))

### Features

- configure if decorations are hidden on stream end ([#282](https://github.com/ueberdosis/tiptap-pro/issues/282)) ([7fc66c3](https://github.com/ueberdosis/tiptap-pro/commit/7fc66c348baca0b8d853a1a839c99e3a416d65b0))

## [2.19.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.19.1...v2.19.2) (2025-05-25)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.19.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.19.0...v2.19.1) (2025-05-15)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.19.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.18.2...v2.19.0) (2025-05-14)

### Features

- autocomplete as you type ([#261](https://github.com/ueberdosis/tiptap-pro/issues/261)) ([#262](https://github.com/ueberdosis/tiptap-pro/issues/262)) ([d18f4d1](https://github.com/ueberdosis/tiptap-pro/commit/d18f4d1bde28856aad15a16681ed025bf63f62ba))

## [2.18.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.18.1...v2.18.2) (2025-05-13)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.18.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.18.0...v2.18.1) (2025-05-12)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.18.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.8...v2.18.0) (2025-04-17)

### Features

- update list of openai models ([9a7b6f8](https://github.com/ueberdosis/tiptap-pro/commit/9a7b6f8de6157279e6b618b990ad8e202d4ce9ae))

## [2.17.8](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.7...v2.17.8) (2025-04-11)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.17.7](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.6...v2.17.7) (2025-04-11)

### Bug Fixes

- create new paragraph if the generated text is plain text and it is outside the content ([75df53c](https://github.com/ueberdosis/tiptap-pro/commit/75df53c0dc096920572eb8c1e0f3cd005111199b))

## [2.17.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.5...v2.17.6) (2025-03-29)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.17.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.5-beta.0...v2.17.5) (2025-02-26)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.17.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.3...v2.17.4) (2025-02-11)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.17.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.2...v2.17.3) (2025-01-30)

### Bug Fixes

- **autocompletion:** correct linting errors ([9930c1a](https://github.com/ueberdosis/tiptap-pro/commit/9930c1a06081b371c78626636535ea3ce2ea215a))

### Features

- **autocompletion:** enhance trigger options with accept, debounce ([9e78d8b](https://github.com/ueberdosis/tiptap-pro/commit/9e78d8bea280d965364a814c99c6ad85517abb48))

## [2.17.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.1...v2.17.2) (2025-01-07)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.17.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.17.0...v2.17.1) (2024-12-30)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.17.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.16.5-beta.2...v2.17.0) (2024-12-20)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.16.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.16.2...v2.16.3) (2024-11-28)

### Bug Fixes

- **emoji:** preserve marks in stored marks when inserting an emoji ([#143](https://github.com/ueberdosis/tiptap-pro/issues/143)) ([5ebbed4](https://github.com/ueberdosis/tiptap-pro/commit/5ebbed4ffa46643350fb52f12985770acbae37a8))
- prevent autocomplete api calls on pressing tab key ([#142](https://github.com/ueberdosis/tiptap-pro/issues/142)) ([95c157a](https://github.com/ueberdosis/tiptap-pro/commit/95c157a4875f341ab70bad8ec826a77ca27b1b02))

## [2.16.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.16.1...v2.16.2) (2024-11-27)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.16.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.16.0...v2.16.1) (2024-11-26)

### Bug Fixes

- **mathematics:** do some bounds checking to make the root doc not be asked what it's before or after is ([#140](https://github.com/ueberdosis/tiptap-pro/issues/140)) ([7af2b73](https://github.com/ueberdosis/tiptap-pro/commit/7af2b73c45a2284d908c649580c4acd402b61620))

# [2.16.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.15.0...v2.16.0) (2024-11-25)

### Features

- **table-of-contents:** add a command to force refresh the table of contents ([#132](https://github.com/ueberdosis/tiptap-pro/issues/132)) ([dafc61e](https://github.com/ueberdosis/tiptap-pro/commit/dafc61eadc16b88f3d95ad2a107fec79fe01ddbd))

# [2.15.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.14.1...v2.15.0) (2024-11-20)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.14.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.14.0...v2.14.1) (2024-11-14)

### Bug Fixes

- **ai:** bounds checking, extract html ([#135](https://github.com/ueberdosis/tiptap-pro/issues/135)) ([2f277b8](https://github.com/ueberdosis/tiptap-pro/commit/2f277b8524532d44579865e36c6abe337e293ee1))

# [2.14.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.13.0...v2.14.0) (2024-11-07)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.13.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.11-beta.5...v2.13.0) (2024-10-31)

### Features

- **snapshot-compare:** first version of snapshot compare ([#113](https://github.com/ueberdosis/tiptap-pro/issues/113)) ([8462002](https://github.com/ueberdosis/tiptap-pro/commit/846200247a614da8ce2dbc410665221f8e9324bc))

## [2.11.9](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.8...v2.11.9) (2024-10-02)

### Bug Fixes

- **ai:** resolve an off-by-one error when continue writing was used ([5824995](https://github.com/ueberdosis/tiptap-pro/commit/582499579a10675165420449fb7f1363c2382753))

## [2.11.8](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.7...v2.11.8) (2024-10-02)

### Bug Fixes

- implement defaultResolver for autocomplete ([c927b35](https://github.com/ueberdosis/tiptap-pro/commit/c927b35135b5efa3a3af2f791425407daedf57ce))

## [2.11.7](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.6...v2.11.7) (2024-09-27)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.11.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.5...v2.11.6) (2024-09-27)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.11.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.4...v2.11.5) (2024-09-27)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.11.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.3...v2.11.4) (2024-09-26)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.11.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.2...v2.11.3) (2024-09-24)

### Bug Fixes

- aiAccept works on a non-streamed response now ([#126](https://github.com/ueberdosis/tiptap-pro/issues/126)) ([c0cdc4e](https://github.com/ueberdosis/tiptap-pro/commit/c0cdc4e341ef13e5dc6d6b4b002d9ba8468bb0aa))

## [2.11.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.1...v2.11.2) (2024-08-30)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.11.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.11.0...v2.11.1) (2024-08-23)

### Bug Fixes

- apply aiMark in 1 step to fix history + position fixes ([#112](https://github.com/ueberdosis/tiptap-pro/issues/112)) ([b06f76c](https://github.com/ueberdosis/tiptap-pro/commit/b06f76cb5dda5c370bd4f2ff2976e12751da8fa1))

# [2.11.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.11...v2.11.0) (2024-08-21)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.10.11](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.10...v2.10.11) (2024-08-09)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.10.10](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.9...v2.10.10) (2024-08-08)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.10.9](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.8...v2.10.9) (2024-08-06)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.10.8](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.7...v2.10.8) (2024-08-06)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.10.7](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.6...v2.10.7) (2024-07-31)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.10.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.5...v2.10.6) (2024-07-31)

### Features

- add support for gpt-4o-mini ([eb18df4](https://github.com/ueberdosis/tiptap-pro/commit/eb18df4cbe2917f49430818f30d9afea3de0bc8f))

## [2.10.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.4...v2.10.5) (2024-07-26)

### Bug Fixes

- do not emit errors on invalid content ([#111](https://github.com/ueberdosis/tiptap-pro/issues/111)) ([6e38519](https://github.com/ueberdosis/tiptap-pro/commit/6e38519d9cacf9e7a75bdda2220e2248bafbf6cb))

## [2.10.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.3...v2.10.4) (2024-07-26)

### Bug Fixes

- ai-advanced extension now can use editor.storage.aiAdvanced ([f33f2ee](https://github.com/ueberdosis/tiptap-pro/commit/f33f2ee02eefab5e1f705765fdee798773952603))

## [2.10.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.2...v2.10.3) (2024-07-16)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.10.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.1...v2.10.2) (2024-07-15)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.10.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.10.0...v2.10.1) (2024-07-15)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.10.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.9.3...v2.10.0) (2024-07-14)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.9.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.9.2...v2.9.3) (2024-07-05)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.9.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.9.1...v2.9.2) (2024-06-28)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.9.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.9.0...v2.9.1) (2024-06-26)

### Bug Fixes

- typing was off ([0aee771](https://github.com/ueberdosis/tiptap-pro/commit/0aee771f5a70a59d837d87b950fed57f30c87fff))

# [2.9.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.9...v2.9.0) (2024-06-26)

### Bug Fixes

- account for offset in normal text ([75e6e51](https://github.com/ueberdosis/tiptap-pro/commit/75e6e516076418e39aa297ca8bb82374c7a9dda7))
- **ai:** account for an off-by-one bug with appending ([8789ca0](https://github.com/ueberdosis/tiptap-pro/commit/8789ca0da6eb6d76e17337d7ee6fd3e253ada844))
- **ai:** resolve a minor prosemirror parser issue with handling partial HTML ([4c36244](https://github.com/ueberdosis/tiptap-pro/commit/4c36244804932532e6d514fac1f360008fe5630c))
- allow regenerating better ([c62a71a](https://github.com/ueberdosis/tiptap-pro/commit/c62a71ae511b87ddb2808d95c52d97672e49865b))
- check for undefined step ([d538512](https://github.com/ueberdosis/tiptap-pro/commit/d53851298bd87d19b96d5422e56413a2c18ec80d))
- clear pastResponses on accept ([39146f6](https://github.com/ueberdosis/tiptap-pro/commit/39146f667fc908db1b49773517ade5a1d52ea7ce))
- do not preserve whitespace on injection ([1a5d142](https://github.com/ueberdosis/tiptap-pro/commit/1a5d1426dedc7f327ac515cf74bd1fa062808b79))
- insert response at correct position ([aa9b3c0](https://github.com/ueberdosis/tiptap-pro/commit/aa9b3c0c0ef906b4a1c3624fd58605be5dc4785d))
- no input rules on accept ([7430b83](https://github.com/ueberdosis/tiptap-pro/commit/7430b839f9df7f43ce24cc5a307ddde0689f5b78))
- remove custom command ([5a0a611](https://github.com/ueberdosis/tiptap-pro/commit/5a0a6119059b26c40d5b4ff8289b36e3f81f8d75))
- resolve off-by-one bug in accepting response ([e3f9074](https://github.com/ueberdosis/tiptap-pro/commit/e3f9074fd80f0d83405994d6e8486f5e5db1b7f1))
- return true explicitly, not a promise ([c25dc80](https://github.com/ueberdosis/tiptap-pro/commit/c25dc80cada3cd6d9c43d4f61ee518458d9ca02f))
- the try needs to wrap the whole chain ([d6bc998](https://github.com/ueberdosis/tiptap-pro/commit/d6bc998c34b569ec5dfd7ea77b8281bd17ebef33))
- wrangle the types for ai-advanced ([c205c12](https://github.com/ueberdosis/tiptap-pro/commit/c205c12d231664322fe84d9d3dc103fdeb38c065))

### Features

- add `aiCustom` command ([6a61da5](https://github.com/ueberdosis/tiptap-pro/commit/6a61da5c1b04e236aa95608665078a3fe64b819b))
- add `aiKeypoints` command ([12ccd7b](https://github.com/ueberdosis/tiptap-pro/commit/12ccd7b66867c642a1887ee2c64c1da8c64a13a2))
- add support for injectAt ([f6bc79d](https://github.com/ueberdosis/tiptap-pro/commit/f6bc79d0dfeb80f4d727c59cfe8227532a9b3253))
- ai regenerate response & response history ([e9d2815](https://github.com/ueberdosis/tiptap-pro/commit/e9d2815aa1d1f8a166491adf15a24605c162a562))
- **ai:** rejecting mid-response will cancel the request ([4d9356c](https://github.com/ueberdosis/tiptap-pro/commit/4d9356c848f9072a910cbbb5f3c1e6780f92720b))
- clean up the AI extension while supporting all the new features ([0a7295c](https://github.com/ueberdosis/tiptap-pro/commit/0a7295cffa373a5d16868e1d7da9ca15f4fc41cf))
- disable prompting when already executing ([e942bf6](https://github.com/ueberdosis/tiptap-pro/commit/e942bf67032bb8552e221ca004fa76b3ca3f7a2a))
- export tryParseToTiptapHTML ([12ba0c5](https://github.com/ueberdosis/tiptap-pro/commit/12ba0c583fceb5a2dd4594cd54a21e6b9137598c))
- include context feature into prompt ([ba472d1](https://github.com/ueberdosis/tiptap-pro/commit/ba472d19c7e912d99107ee8106e69226d4bd1faf))
- make applying aiMark configurable ([a7d7a57](https://github.com/ueberdosis/tiptap-pro/commit/a7d7a57f8499c39080dc59ffea1903a950136ba3))
- markdown streaming poc from [@mkriegeskorte](https://github.com/mkriegeskorte) ([64f93d5](https://github.com/ueberdosis/tiptap-pro/commit/64f93d551041fc42b9b2b7cb3ea2e8b24698fe7c))
- more changes for demo ([a8fad9a](https://github.com/ueberdosis/tiptap-pro/commit/a8fad9ad4e9d961564a6511a1aaa425410424bc6))

# [3.0.0-beta.4](https://github.com/ueberdosis/tiptap-pro/compare/v3.0.0-beta.3...v3.0.0-beta.4) (2024-02-08)

# [3.0.0-beta.3](https://github.com/ueberdosis/tiptap-pro/compare/v3.0.0-beta.2...v3.0.0-beta.3) (2024-02-08)

# [3.0.0-beta.2](https://github.com/ueberdosis/tiptap-pro/compare/v3.0.0-beta.1...v3.0.0-beta.2) (2024-02-08)

# [3.0.0-beta.1](https://github.com/ueberdosis/tiptap-pro/compare/v3.0.0-beta.0...v3.0.0-beta.1) (2024-02-08)

# [3.0.0-beta.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.5...v3.0.0-beta.0) (2024-02-08)

### Features

- **extension-ai:** pass type to onLoading callback and add to autocompletion ([#75](https://github.com/ueberdosis/tiptap-pro/issues/75)) ([d681745](https://github.com/ueberdosis/tiptap-pro/commit/d68174596434a670ee497a6a413d90d23a22f81c))

## [2.8.9](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.8...v2.8.9) (2024-06-03)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.8.8](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.7...v2.8.8) (2024-05-27)

### Bug Fixes

- remove the ai mark after generation ([#92](https://github.com/ueberdosis/tiptap-pro/issues/92)) ([ec37eee](https://github.com/ueberdosis/tiptap-pro/commit/ec37eee1cc30ab569b58e6bb3333a2072bdab87c))

## [2.8.7](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.6...v2.8.7) (2024-05-15)

### Features

- expose new `gpt-4o` model ([17c3517](https://github.com/ueberdosis/tiptap-pro/commit/17c3517edb8185e768407945e44947bfccdf84d6))

## [2.8.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.5...v2.8.6) (2024-05-08)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.8.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.4...v2.8.5) (2024-05-08)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.8.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.3...v2.8.4) (2024-05-08)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.8.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.2...v2.8.3) (2024-05-08)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.8.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.1...v2.8.2) (2024-05-06)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.8.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.8.0...v2.8.1) (2024-04-12)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.8.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.7...v2.8.0) (2024-04-05)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.7.7](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.6...v2.7.7) (2024-03-28)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.7.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.5...v2.7.6) (2024-03-14)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.7.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.4...v2.7.5) (2024-02-20)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.7.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.3...v2.7.4) (2024-02-20)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.7.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.1...v2.7.3) (2024-02-20)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.7.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.1...v2.7.2) (2024-02-16)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.7.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.7.0...v2.7.1) (2024-02-16)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.7.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.5...v2.7.0) (2024-02-15)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.6.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.4...v2.6.5) (2024-02-07)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.6.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.3...v2.6.4) (2024-01-29)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.6.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.2...v2.6.3) (2024-01-22)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.6.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.1...v2.6.2) (2024-01-19)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.6.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.3...v2.6.1) (2024-01-16)

### Reverts

- Revert "switch to rc tiptap versions for release candidate" ([d397698](https://github.com/ueberdosis/tiptap-pro/commit/d39769817f2cc39e919b73e0bb18072bcc46dd45))

# [2.6.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.6.0-rc.0...v2.6.0) (2024-01-09)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.5.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.5.1...v2.5.2) (2024-01-09)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.5.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.5.0...v2.5.1) (2023-12-08)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.5.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.4.1...v2.5.0) (2023-11-27)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.4.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.4.0...v2.4.1) (2023-11-21)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.4.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.4...v2.4.0) (2023-11-16)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.3.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.3...v2.3.4) (2023-11-15)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.3.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.2...v2.3.3) (2023-10-14)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.3.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.1...v2.3.2) (2023-10-12)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.3.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.3.0...v2.3.1) (2023-10-06)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.3.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.4...v2.3.0) (2023-09-27)

### Bug Fixes

- **extension-ai:** fix errors in case of multiple triggering ([c738a59](https://github.com/ueberdosis/tiptap-pro/commit/c738a59c83662dccf482397956e09e8f94429839))

## [2.2.2-rc.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.2...v2.2.2-rc.3) (2023-09-04)

## [2.2.2-rc.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.1...v2.2.2-rc.2) (2023-09-04)

## [2.2.2-rc.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.0...v2.2.2-rc.1) (2023-09-04)

## [2.2.2-rc.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.1...v2.2.2-rc.0) (2023-08-22)

## [2.2.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.3...v2.2.4) (2023-09-19)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.2.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2...v2.2.3) (2023-09-11)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.2.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.1...v2.2.2) (2023-09-08)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.2.2-rc.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.2...v2.2.2-rc.3) (2023-09-04)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.2.2-rc.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.1...v2.2.2-rc.2) (2023-09-04)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.2.2-rc.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.2-rc.0...v2.2.2-rc.1) (2023-09-04)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.2.2-rc.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.1...v2.2.2-rc.0) (2023-08-22)

**Note:** Version bump only for package @tiptap-pro/extension-ai

## [2.2.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0...v2.2.1) (2023-08-22)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.2.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.6...v2.2.0) (2023-08-19)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.2.0-rc.6](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.5...v2.2.0-rc.6) (2023-08-11)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.2.0-rc.5](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.4...v2.2.0-rc.5) (2023-08-09)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.2.0-rc.4](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.3...v2.2.0-rc.4) (2023-08-04)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.2.0-rc.3](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.2...v2.2.0-rc.3) (2023-07-31)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.2.0-rc.2](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.1...v2.2.0-rc.2) (2023-07-26)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.2.0-rc.1](https://github.com/ueberdosis/tiptap-pro/compare/v2.2.0-rc.0...v2.2.0-rc.1) (2023-07-26)

**Note:** Version bump only for package @tiptap-pro/extension-ai

# [2.2.0-rc.0](https://github.com/ueberdosis/tiptap-pro/compare/v2.1.0...v2.2.0-rc.0) (2023-07-22)

**Note:** Version bump only for package @tiptap-pro/extension-ai
